﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Report_0507
{
    public class User
    {
        public string IdNumber { get; set; } = "";
        public string Name { get; set; } = "";
        public DateTime Birthday { get; set; }
        public string Email { get; set; } = "";
    }
}
